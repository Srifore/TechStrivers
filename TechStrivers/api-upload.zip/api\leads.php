<?php
require __DIR__ . '/config.php';
require __DIR__ . '/crud_helper.php';

// Leads contain PII, so unlike every other resource, reading the list
// requires admin auth. Creating one (the public enquiry form) does not.
handle_crud($pdo, 'leads', [], false, true, [
    'date' => date('Y-m-d H:i'),
    'status' => 'New',
    'notes' => '',
]);
